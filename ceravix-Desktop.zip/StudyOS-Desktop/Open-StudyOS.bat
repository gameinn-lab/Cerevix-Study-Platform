@echo off
REM Opens StudyOS in its own app window (Edge or Chrome). Works offline.
set "APP=%~dp0StudyOS.html"
set "URL=file:///%APP:\=/%"
set "PROF=%LOCALAPPDATA%\StudyOS-profile"
set "BR="
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set "BR=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set "BR=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" set "BR=%LocalAppData%\Google\Chrome\Application\chrome.exe"
if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" set "BR=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" set "BR=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if "%BR%"=="" goto fallback
start "" "%BR%" --app="%URL%" --user-data-dir="%PROF%"
exit /b
:fallback
start "" "%APP%"
