@echo off
REM Creates a "StudyOS" shortcut with the StudyOS icon on your Desktop.
powershell -NoProfile -ExecutionPolicy Bypass -Command "$d=[Environment]::GetFolderPath('Desktop');$s=(New-Object -ComObject WScript.Shell).CreateShortcut($d+'\StudyOS.lnk');$s.TargetPath='%~dp0Open-StudyOS.bat';$s.WorkingDirectory='%~dp0';$s.IconLocation='%~dp0studyos.ico';$s.WindowStyle=7;$s.Save()"
echo Done. Look for StudyOS on your Desktop.
pause
