#!/bin/bash
# Linux: opens StudyOS in its own app window. Works offline.
cd "$(dirname "$0")"; APP="$PWD/StudyOS.html"; PROF="$HOME/.studyos-profile"
for B in google-chrome chromium chromium-browser microsoft-edge brave-browser; do
  if command -v "$B" >/dev/null 2>&1; then nohup "$B" --app="file://$APP" --user-data-dir="$PROF" >/dev/null 2>&1 & exit 0; fi
done
xdg-open "$APP"
