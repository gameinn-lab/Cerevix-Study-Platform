#!/bin/bash
# macOS: opens StudyOS in its own app window (Chrome/Edge/Brave). Works offline.
cd "$(dirname "$0")"; APP="$PWD/StudyOS.html"; PROF="$HOME/.studyos-profile"
for B in "Google Chrome" "Microsoft Edge" "Brave Browser"; do
  if [ -d "/Applications/$B.app" ]; then open -na "$B" --args --app="file://$APP" --user-data-dir="$PROF"; exit 0; fi
done
open "$APP"
