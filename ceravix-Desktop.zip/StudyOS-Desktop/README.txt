StudyOS - Desktop App (offline)
================================
WINDOWS : 1) Zip ko Extract karo (folder ko Documents ya Desktop me rakho).
          2) Open-StudyOS.bat par double-click.
          3) (Optional) Create-Desktop-Shortcut.bat chalao -> Desktop par StudyOS icon aa jayega.
MAC     : Open-StudyOS.command par double-click. (Pehli baar: right-click > Open.)
LINUX   : ./open-studyos.sh   (pehle: chmod +x open-studyos.sh)
KOI BHI DEVICE (phone/tablet): StudyOS.html file direct browser me kholo,
          ya StudyOS-app.zip ko Netlify par upload karke "Install app" / "Add to Home Screen" karo.

ZAROORI BAATEN
- Data aapke computer me hi save hota hai. Settings > Export JSON se regular backup lo.
- Folder ko baad me move/rename mat karo; karoge to dobara launcher chalao aur Import JSON se backup restore karo.
- Chrome ya Edge install hona chahiye. Na ho to StudyOS.html normal browser me khulega.
- AI features ke liye internet + Settings me apni API key chahiye.
